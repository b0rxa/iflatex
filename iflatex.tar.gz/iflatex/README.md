# ifirak
LaTeX templates for teaching and research documents from the Computer Science Faculty (UPV/EHU)
